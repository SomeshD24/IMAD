from django.urls import path, include
from rest_framework import routers
from .views import RestaurantViewSet, MenuItemViewSet

router = routers.DefaultRouter()
router.register(r'restaurants', RestaurantViewSet, basename='restaurants')
router.register(r'menu-items', MenuItemViewSet, basename='menu-items')

urlpatterns = [
    path('', include(router.urls)),
]