from django.db import models
from accounts.models import CustomUser 
from restaurant.models import Restaurant

class Order(models.Model):
    user = models.ForeignKey(CustomUser , on_delete=models.CASCADE)
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE)
    items = models.JSONField()  # Store item IDs and quantities
    total = models.DecimalField(max_digits=10, decimal_places=2)
    delivery_address = models.CharField(max_length=255)
    order_date = models.DateTimeField(auto_now_add=True)