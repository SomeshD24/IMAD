// src/utils/cartStorage.js

export const fetchCartItemsFromLocalStorage = () => {
    const cartItems = localStorage.getItem('cartItems');
    return cartItems ? JSON.parse(cartItems) : [];
};

export const clearCartItemsFromLocalStorage = () => {
    localStorage.removeItem('cartItems');
};

export const saveCartItemsToLocalStorage = (items) => {
    localStorage.setItem('cartItems', JSON.stringify(items));
};