// src/components/Register.js
import React, { useState } from 'react';
import { registerUser  } from '../api';
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState(''); // Ensure setError is defined here
    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError(''); // Reset error state
        const userData = { username, password, email };
        console.log("Sending registration data:", userData); // Log the data being sent
        try {
            await registerUser (userData);
            navigate('/login'); // Redirect to login on success
        } catch (error) {
            console.error("Registration failed", error); // Log the full error object
            // Check if the error response has a message
            const errorMessage = error.response?.data?.detail || error.message || 'Registration failed. Please try again.';
            setError(errorMessage); // Set error message
        }
    };

    return (
        <div>
            <h1>Register</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>} {/* Display error message if exists */}
            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <input
                    type="email"
                    placeholder="Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <button type="submit">Register</button>
            </form>
        </div>
    );
};

export default Register;