// src/components/Cart.js
import React, { useState, useEffect } from 'react';
import { placeOrder } from '../api';
import { fetchCartItemsFromLocalStorage, clearCartItemsFromLocalStorage } from '../utils/cartStorage';

const Cart = () => {
    const [cartItems, setCartItems] = useState([]);
    const [total, setTotal] = useState(0);

    useEffect(() => {
        const fetchCartItems = async () => {
            const cartItemsData = fetchCartItemsFromLocalStorage();
            setCartItems(cartItemsData);
            setTotal(cartItemsData.reduce((acc, item) => acc + item.price, 0));
        };
        fetchCartItems();
    }, []);

    const handlePlaceOrder = async () => {
        try {
            await placeOrder({ items: cartItems, total });
            clearCartItemsFromLocalStorage(); // Clear cart items from local storage
            // Redirect to home page or show success message
            window.location.href = '/';
        } catch (error) {
            console.error("Order placement failed", error);
        }
    };

    return (
        <div>
            <h1>Cart</h1>
            <ul>
                {cartItems.map((item) => (
                    <li key={item.id}>
                        {item.name} - ${item.price}
                    </li>
                ))}
            </ul>
            <p>Total: ${total}</p>
            <button onClick={handlePlaceOrder}>Place Order</button>
        </div>
    );
};

export default Cart;

