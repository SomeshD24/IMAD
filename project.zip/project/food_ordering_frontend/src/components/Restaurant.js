// src/components/Restaurant.js
import React, { useState, useEffect } from 'react';
import { fetchMenuItems } from '../api';
import { useParams } from 'react-router-dom';

const Restaurant = () => {
    const { id } = useParams();
    const [menuItems, setMenuItems] = useState([]);

    useEffect(() => {
        const fetchMenuItemsData = async () => {
            const response = await fetchMenuItems(id);
            setMenuItems(response.data);
        };
        fetchMenuItemsData();
    }, [id]);

    return (
        <div>
            <h1>Menu Items</h1>
            <ul>
                {menuItems.map((menuItem) => (
                    <li key={menuItem.id}>
                        {menuItem.name} - ${menuItem.price}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Restaurant;