// src/components/Home.js
import React, { useState, useEffect } from 'react';
import { fetchRestaurants } from '../api';
import { Link } from 'react-router-dom';

const Home = () => {
    const [restaurants, setRestaurants] = useState([]);

    useEffect(() => {
        const fetchRestaurantsData = async () => {
            const response = await fetchRestaurants();
            setRestaurants(response.data);
        };
        fetchRestaurantsData();
    }, []);

    return (
        <div>
            <h1>Restaurants</h1>
            <ul>
                {restaurants.map((restaurant) => (
                    <li key={restaurant.id}>
                        <Link to={`/restaurants/${restaurant.id}`}>
                            {restaurant.name}
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Home;