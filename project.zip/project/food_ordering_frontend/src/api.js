// src/api.js
import axios from 'axios';

const API_URL = 'http://localhost:8000/api/'; // Adjust the URL as needed

export const registerUser  = (userData) => {
    return axios.post(`${API_URL}register/`, userData);
};

export const loginUser  = (credentials) => {
    return axios.post(`${API_URL}login/`, credentials);
};

export const fetchRestaurants = () => {
    return axios.get(`${API_URL}restaurants/`);
};

export const fetchMenuItems = () => {
    return axios.get(`${API_URL}menu-items/`);
};

export const placeOrder = (orderData) => {
    return axios.post(`${API_URL}orders/`, orderData);
};